package ps2.carro;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping (value = "/api")

public class CarroControle{
  @Autowired
  private CarroRepositorio repositorioCarro;
  //GET -> read
  @RequestMapping(value = "/carros", method = RequestMethod.GET)
  public List<Carro> getCarros(){
    return repositorioCarro.findAll();
  }
  
  @GetMapping("/carros/{id}")
  public ResponseEntity<Carro> GetById(@PathVariable(value = "id") long id){
    Optional<Carro> carro = repositorioCarro.findById(id);
    
      if(carro.isPresent()){
        return new ResponseEntity<Carro>(carro.get(), HttpStatus.OK);
      }
      else{
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
      }
  }

  //GET  - busca avançada
  @GetMapping("/carros/find4")
  public List<Carro> GetByModelo(@RequestParam(name = "texto", defaultValue="") String modelo){
    return repositorioCarro.findByModelo(modelo);
  }
  
  @GetMapping("/carros/find5")
  public List<Carro> GetByMarca(@RequestParam(name = "texto", defaultValue="") String marca){
    return repositorioCarro.findByMarca(marca);
  }

  @GetMapping("/carros/find6")
  public List<Carro> GetByAno(@RequestParam(name = "texto", defaultValue="") long ano){
    return repositorioCarro.findByAno(ano);
  }
  
  @GetMapping("/carros/find7")
  public List<Carro> GetByCategoria(@RequestParam(name = "texto", defaultValue="") String categoria){
    return repositorioCarro.findByCategoria(categoria);
  }
  
//POST -> create
  @RequestMapping(value = "/carros", method = RequestMethod.POST)
  public Carro postCarro(@RequestBody Carro carro){
    return repositorioCarro.save(carro);
  }
//PUT -> update
  @RequestMapping(value = "/carros/{id}", method = RequestMethod.PUT)
  public ResponseEntity<Carro> putCarro(@PathVariable(value = "id") long id, @RequestBody Carro newCarro){
    Optional <Carro> outroCarro = repositorioCarro.findById(id);
    if(outroCarro.isPresent()){
      Carro carro = outroCarro.get();
      //carro.setId(newCarro.getId());
      carro.setModelo(newCarro.getModelo());
      carro.setMarca(newCarro.getMarca());
      carro.setAno(newCarro.getAno());
      carro.setCategoria(newCarro.getCategoria());
      repositorioCarro.save(carro);
      return new ResponseEntity<Carro>(carro, HttpStatus.OK);
    }else{
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
//DELETE -> delete
@RequestMapping(value = "/carros/{id}", method = RequestMethod.DELETE)
  public ResponseEntity <Carro> deleteCarro(@PathVariable(value = "id") long id){
    Optional <Carro> carro = repositorioCarro.findById(id);
      if(carro.isPresent()){
        repositorioCarro.delete(carro.get());
        //repositorioCarro.save(carro);
        return new ResponseEntity<>(HttpStatus.OK);
      }
      else{
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
      }
  }
  
}