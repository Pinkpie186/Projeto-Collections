package ps2.carro;

import javax.persistence.*;

@Entity
@Table (name = "carros")
public class Carro{
  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE)
  private long id;
  private String modelo;
  private String marca;
  private long ano;
  private String categoria;

  public Carro(){
  }

  public Carro(long id, String modelo, String marca, long ano, String categoria){
    this.id = id;
    this.modelo = modelo;
    this.marca = marca;
    this.ano = ano;
    this.categoria = categoria;
  }

  public long getId(){
    return this.id;
  }
  public void setId(long id){
    this.id = id;
  }
  
  public String getModelo(){
    return this.modelo;
  }
  public void setModelo(String modelo){
    this.modelo = modelo;
  }
  
  public String getMarca(){
    return this.marca;
  }
  public void setMarca(String marca){
    this.marca = marca;
  }
  
  public long getAno(){
    return this.ano;
  }
  public void setAno(long ano){
    this.ano = ano;
  }
  
  public String getCategoria(){
    return this.categoria;
  }
  public void setCategoria(String categoria){
    this.categoria = categoria;
  }
  
  public String toString(){
    return "\tCarro" + "\nID: " + id + "\nModelo do Carro: " + modelo + "\nMarca: " + marca + "\nAno: " + ano + "\nCategoria do Carro: " + categoria;
  }
  
}