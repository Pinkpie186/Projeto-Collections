package ps2.carro;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface CarroRepositorio extends JpaRepository<Carro, Long> {
  //SELECT * FROM Carro;
  List<Carro> findByModelo(String modelo);
  List<Carro> findByMarca(String marca);
  List<Carro> findByAno(long ano);
  List<Carro> findByCategoria(String categoria);
}
