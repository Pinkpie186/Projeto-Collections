package ps2.contaBanc;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping (value = "/api")
public class ContaControle{
  @Autowired
  private ContaRepositorio repositorioConta;

  //le
  @RequestMapping(value = "/contas", method = RequestMethod.GET)
  public List<Conta> getContas(){
    return repositorioConta.findAll();
  }
  //@PathVariable: indica variavel traz as informações
  
    //Devolve uma única pergunta e resposta com todos os dados. 
    //Neste caso o id, pergunta e resposta
  @GetMapping("/contas/{id}")
  public ResponseEntity<Conta>GetById(@PathVariable(value = "id") long id){
    Optional<Conta> conta = repositorioConta.findById(id);
      if(conta.isPresent()){
        return new ResponseEntity<Conta>(conta.get(), HttpStatus.OK);
      }else{
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
      }
  }

  //GET  - busca avançada
  @GetMapping("/contas/find")
  public List<Conta> GetByNomeTitular(@RequestParam(name = "texto", defaultValue="") String nomeTitular){
    return repositorioConta.findByNomeTitular(nomeTitular);
  }
  
  @GetMapping("/contas/find2")
  public List<Conta> GetBySaldo(@RequestParam(name = "texto", defaultValue="") long saldo){
    return repositorioConta.findBySaldo(saldo);
  }

  @GetMapping("/contas/find3")
  public List<Conta> GetByNumAgencia(@RequestParam(name = "texto", defaultValue="") long numAgencia){
    return repositorioConta.findByNumAgencia(numAgencia);
  }


  //cria
  @RequestMapping(value = "/contas", method = RequestMethod.POST)
  public Conta postConta(@RequestBody Conta conta){
    return repositorioConta.save(conta);
  }

  //atualiza
  @RequestMapping(value = "/contas/{id}", method = RequestMethod.PUT)
  public ResponseEntity<Conta> putConta(@PathVariable(value = "id") long id, @RequestBody Conta newConta){
    Optional <Conta> contaAntiga = repositorioConta.findById(id);
    if(contaAntiga.isPresent()){
      Conta conta = contaAntiga.get();
      //conta.setId(newConta.getId());
      conta.setNomeTitular(newConta.getNomeTitular());
      conta.setSaldo(newConta.getSaldo());
      conta.setNumAgencia(newConta.getNumAgencia());
      repositorioConta.save(conta);
      return new ResponseEntity<Conta>(conta, HttpStatus.OK);
    }else{
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}

  //deleta
  @RequestMapping(value = "/contas/{id}", method = RequestMethod.DELETE)
  public ResponseEntity<Conta> deleteConta(@PathVariable(value = "id") long id){
    Optional <Conta> conta = repositorioConta.findById(id);
      if(conta.isPresent()){
        repositorioConta.delete(conta.get());
        //repositorioConta.save(conta);
        return new ResponseEntity<>(HttpStatus.OK);
      }else{
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
      }
  }
  
}


//idConta passa a ser apenas id

/*@GetMapping: Determina que o método aceitará requisições HTTP do tipo GET. 
@PostMapping: Determina que o método aceitará requisições HTTP do tipo POST. 
@PutMapping: Determina que o método aceitará requisições HTTP do tipo PUT.*/