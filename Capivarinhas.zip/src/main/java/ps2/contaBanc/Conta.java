package ps2.contaBanc;

import javax.persistence.*;

@Entity
@Table (name = "contas")
public class Conta{
  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE)
  private long id;
  private String nomeTitular;
  private long saldo;
  private long numAgencia;

  public Conta(){
  }

  public Conta(long id, String nomeTitular, long saldo, long numAgencia){
    this.id = id;
    this.nomeTitular = nomeTitular;
    this.saldo = saldo;
    this.numAgencia = numAgencia;
  }

  public long getId(){
    return this.id;
  }
  public void setId(long id) {
        this.id = id;
  }
  
  public String getNomeTitular(){
    return this.nomeTitular;
  }
  public void setNomeTitular(String nomeTitular) {
        this.nomeTitular = nomeTitular;
  }
  
  public long getSaldo(){
    return this.saldo;
  }
  public void setSaldo(long saldo) {
        this.saldo = saldo;
  }
  
  public long getNumAgencia(){
    return this.numAgencia;
  }
  public void setNumAgencia(long numAgencia) {
        this.numAgencia = numAgencia;
  }

  public String toString(){
    return "\tConta Bancária" + "\nId: " + id + "\nNome do Titular: " + nomeTitular + "\nSaldo: " + saldo + "\nNúmero Agencia: " + numAgencia;
  }
}