package ps2.contaBanc;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface ContaRepositorio extends JpaRepository<Conta, Long> {
  //SELECT * FROM  '%in%';
  List<Conta> findByNomeTitular(String nomeTitular);
  List<Conta> findBySaldo(long saldo);
  List<Conta> findByNumAgencia(long numAgencia);
}
