package ps2.time;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface TimeRepositorio extends JpaRepository<Time, Long> {
  //SELECT * FROM Time;
  List<Time> findByNomeTime(String nomeTime);
  List<Time> findByAnoFund(long anoFund);
  List<Time> findByCidade(String cidade);
  List<Time> findByEstado(String estado);
}
