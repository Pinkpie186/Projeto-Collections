package ps2.time;

import javax.persistence.*;

@Entity
@Table (name = "times")
public class Time{
  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE)
  private long id;
  private String nomeTime;
  private long anoFund;
  private String cidade;
  private String estado;

   

  public Time(){
  }

  public Time(long id, String nomeTime, long anoFund, String cidade, String estado){
    this.id = id;
    this.nomeTime = nomeTime;
    this.anoFund = anoFund; 
    this.cidade = cidade;
    this.estado = estado;
  }

  public long getId(){
    return this.id;
  }
  public void setId(long id){
    this.id = id;
  }
  
  public String getNomeTime(){
    return this.nomeTime;
  }
  public void setNomeTime(String nomeTime){
    this.nomeTime = nomeTime;
  }
  
  public long getAnoFund(){
    return this.anoFund;
  }
  public void setAnoFund(long anoFund){
    this.anoFund = anoFund;
  }
  
  public String getCidade(){
    return this.cidade;
  }
  public void setCidade(String cidade){
    this.cidade = cidade;
  }
  
  public String getEstado(){
    return this.estado;
  }
  public void setEstado(String estado){
    this.estado = estado;
  }

  public String toString(){
    return "\tTime" + "\nId: " + id + "\nNome do Time: " + nomeTime + "\nAno de Fundação: " + anoFund + "\nCidade: " + cidade + "\nEstado: " + estado;
  }
  
}