package ps2.time;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping (value = "/api")
public class TimeControle{
  @Autowired
  private TimeRepositorio repositorioTime;

  @RequestMapping(value = "/times", method = RequestMethod.GET)
  //@GetMapping("/times")
  public List<Time> getTimes(){
    return repositorioTime.findAll();
  }

  @GetMapping("/times/{id}")
  public ResponseEntity<Time> GetById(@PathVariable(value = "id") long id){
    Optional<Time> time = repositorioTime.findById(id);
    if(time.isPresent()){
      return new ResponseEntity<Time>(time.get(), HttpStatus.OK);
    }else{
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
  }

  //GET  - busca avançada
  @GetMapping("/times/find8")
  public List<Time> GetByNomeTime(@RequestParam(name = "texto", defaultValue="") String nomeTime){
    return repositorioTime.findByNomeTime(nomeTime);
  }

  @GetMapping("/times/find9")
  public List<Time> GetByAnoFund(@RequestParam(name = "texto", defaultValue="") long anoFund){
    return repositorioTime.findByAnoFund(anoFund);
  }

  @GetMapping("/times/find10")
  public List<Time> GetByCidade(@RequestParam(name = "texto", defaultValue="") String cidade){
    return repositorioTime.findByCidade(cidade);
  }

  @GetMapping("/times/find11")
  public List<Time> GetByEstado(@RequestParam(name = "texto", defaultValue="") String estado){
    return repositorioTime.findByEstado(estado);
  }

//cria
  @RequestMapping(value = "/times", method = RequestMethod.POST)
  public Time posTime(@RequestBody Time time){
    return repositorioTime.save(time);
  }

//atualiza
  @RequestMapping(value = "/times/{id}", method = RequestMethod.PUT)
  public ResponseEntity <Time>  putTime(@PathVariable(value = "id") long id,   @RequestBody Time newTime){
    Optional <Time> timeAntiga = repositorioTime.findById(id);
      if(timeAntiga.isPresent()){
        Time time = timeAntiga.get();
        time.setId(newTime.getId());
        time.setNomeTime(newTime.getNomeTime());
        time.setAnoFund(newTime.getAnoFund());
        time.setCidade(newTime.getCidade());
        time.setEstado(newTime.getEstado());
        repositorioTime.save(time);
        return new ResponseEntity<Time>(time, HttpStatus.OK);
      }else{
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
  

  
  //deleta
  @RequestMapping(value = "/times/{id}", method = RequestMethod.DELETE)
  public ResponseEntity<Time> deleteTime(@PathVariable(value = "id") long id){
    Optional <Time> time = repositorioTime.findById(id);
      if(time.isPresent()){
        repositorioTime.delete(time.get());
        //repositorioTime.save(time);
       return new ResponseEntity<>(HttpStatus.OK);
      }else{
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
      }
  }
  
}